#ifndef CUBES_HPP
#define CUBES_HPP

#include <SFML/Graphics.hpp>

class Cubes : public sf::Drawable{
public:
    void cubesLoad(int window_width,
          int window_height);
        
    void movement(int window_width);

    sf::RectangleShape cubes[3];

private:
    void draw(sf::RenderTarget &target, sf::RenderStates states) const{
        for(int i=0;i<3;i++)
            target.draw(cubes[i], states);
    }

    float speed=0.17147;

    bool sides[3];

    const int width=100;
    const int height=100;
};

#endif // CUBES_HPP