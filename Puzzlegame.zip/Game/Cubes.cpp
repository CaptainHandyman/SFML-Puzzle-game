#include "Cubes.hpp"

void Cubes::cubesLoad(int window_width,
             int window_height){
    for(int i=0;i<3;i++){
        cubes[i].setFillColor(sf::Color(250, 0, 0));
        cubes[i].setSize(sf::Vector2f(width, height));
    }
    cubes[0].setPosition(window_width-width, 200);
    cubes[1].setPosition(0, 400);
    cubes[2].setPosition(window_width-width, 600);
}

void Cubes::movement(int window_width){
    if(sides[0]){
        if(cubes[0].getPosition().x>0)
            cubes[0].move(-speed, 0);
        else if(cubes[0].getPosition().x<=0)
            sides[0]=false;
    }
    else{
        if(cubes[0].getPosition().x<window_width-width)
            cubes[0].move(speed, 0);
        else if(cubes[0].getPosition().x>=window_width-width)
            sides[0]=true;
    }
    if(sides[1]){
        if(cubes[1].getPosition().x<window_width-width)
            cubes[1].move(speed, 0);
        else if(cubes[1].getPosition().x>=window_width-width)
            sides[1]=false;
    }
    else{
        if(cubes[1].getPosition().x>0)
            cubes[1].move(-speed, 0);
        else if(cubes[1].getPosition().x<=0)
            sides[1]=true;
    }
    if(sides[2]){
        if(cubes[2].getPosition().x>0)
            cubes[2].move(-speed, 0);
        else if(cubes[2].getPosition().x<=0)
            sides[2]=false;
    }
    else{
        if(cubes[2].getPosition().x<window_width-width)
            cubes[2].move(speed, 0);
        else if(cubes[2].getPosition().x>=window_width-width)
            sides[2]=true;
    }
}