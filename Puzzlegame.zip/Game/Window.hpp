#ifndef WINDOW_HPP
#define WINDOW_HPP

#include <SFML/Graphics.hpp>

class Window{
public:
    Window();

private:
    const int width = 700;
    const int height = 900;

    const int desktop_width = sf::VideoMode::getDesktopMode().width;
    const int desktop_height = sf::VideoMode::getDesktopMode().height;

    sf::RenderWindow window;
    sf::Event event;
};

#endif // WINDOW_HPP