#include "Player.hpp"

Player::Player(int windowWidth){
    player.setSize(sf::Vector2f(width, height));
    player.setFillColor(sf::Color(250, 0, 0));
    player.setPosition(windowWidth/2-width/2, 0);
    for(int i=0;i<4;i++)
        sides[i]=true;
    point=player.getPosition();
    window_width=windowWidth;
}

void Player::actions(int window_width,
                     int window_height){
    keyboard(window_width,
             window_height);
}

void Player::keyboard(int window_width,
                      int window_height){
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::D)){
        checkCollision(window_width);
        moveRight(window_width);
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::A)){
        checkCollision(window_width);
        moveLeft(window_width);
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::W)){
        checkCollision(window_width);
        moveUp(window_height);
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::S)){
        checkCollision(window_width);
        moveDown(window_height);
    }
}

void Player::moveRight(int window_width){
    if(player.getPosition().x<window_width-width)
        player.move(0.05, 0);
}

void Player::moveLeft(int window_width){
    if(player.getPosition().x>0)
        player.move(-0.05, 0);
}

void Player::moveUp(int window_height){
    if(player.getPosition().y>0)
        player.move(0, -0.05);
}

void Player::moveDown(int window_height){
    if(player.getPosition().y<=window_height-height)
        player.move(0, 0.05);
}

void Player::checkCollision(int windowWidth){
    for(int i=0;i<3;i++){
        if(player.getPosition().x>=boxX[i]-100&&player.getPosition().x<=boxX[i]+100){
            if(player.getPosition().y>=boxY[i]&&player.getPosition().y<=boxY[i]+100){
                player.setPosition(windowWidth/2-width/2, 0);
                dies+=1;
            }
            if(player.getPosition().y+player.getLocalBounds().height>=boxY[i]&&
                player.getPosition().y+player.getLocalBounds().height<=boxY[i]+100){
                player.setPosition(windowWidth/2-width/2, 0);
                dies+=1;
            }
        }
    }
}