#include "Player.hpp"
#include <iostream>
using namespace std;

Player::Player(){
    player.setSize(sf::Vector2f(width, height));
    player.setFillColor(sf::Color(250, 0, 0));
    player.setPosition(0, 0);
    for(int i=0;i<4;i++)
        sides[i]=true;
    point=player.getPosition();
}

void Player::actions(int window_width,
                     int window_height,
                     sf::RenderWindow &window){
    keyboard(window_width,
             window_height,
             window);
}

void Player::keyboard(int window_width,
                      int window_height,
                      sf::RenderWindow &window){
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::D)){
        checkCollision(window);
        if(sides[0])
            moveRight(window_width);
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::A)){
        checkCollision(window);
        if(sides[1])
            moveLeft(window_width);
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::W)){
        checkCollision(window);
        if(sides[2])
            moveUp(window_height);
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::S)){
        checkCollision(window);
        if(sides[3])
            moveDown(window_height);
    }
}

void Player::moveRight(int window_width){
    if(player.getPosition().x<window_width-width)
        player.move(0.05, 0);
}

void Player::moveLeft(int window_width){
    if(player.getPosition().x>0)
        player.move(-0.05, 0);
}

void Player::moveUp(int window_height){
    if(player.getPosition().y>0)
        player.move(0, -0.05);
}

void Player::moveDown(int window_height){
    if(player.getPosition().y<=window_height-height)
        player.move(0, 0.05);
}

void Player::checkCollision(sf::RenderWindow &window){
    for(int i=0;i<3;i++){
        if(player.getPosition().x>=boxX[i]-100&&player.getPosition().x<=boxX[i]+100){
            if(player.getPosition().y>=boxY[i]&&player.getPosition().y<=boxY[i]+100)
                window.close();
            if(player.getPosition().y+player.getLocalBounds().height>=boxY[i]&&
                player.getPosition().y+player.getLocalBounds().height<=boxY[i]+100)
                window.close();
        }
    }
}