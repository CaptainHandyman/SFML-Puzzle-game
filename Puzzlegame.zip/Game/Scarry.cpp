#include "Scarry.hpp"

Scarry::Scarry(){
    texture.loadFromFile("Scarry.png");
    sprite.setTexture(texture);
    sprite.setPosition(0, 0);
    buffer.loadFromFile("Scarry.wav");
    sound.setBuffer(buffer);
    playSound=true;
    drawImage=false;
}

void Scarry::soundPlay(){
    sound.play();
}