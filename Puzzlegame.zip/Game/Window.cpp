#include "Window.hpp"
#include "Player.hpp"
#include "Cubes.hpp"
#include <iostream>
using namespace std;

Player player;

Window::Window(){
    window.create(sf::VideoMode(width, height), "Game", sf::Style::Close);
    window.setPosition(sf::Vector2i(desktop_width/2-width/2, desktop_height/2-height/2));

    Cubes cubes;
    cubes.cubesLoad(width, height);

    while(window.isOpen()){
        while(window.pollEvent(event)){
            if(event.type==sf::Event::Closed)
                window.close();
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
                window.close();
        }

        player.actions(width,
                       height,
                       window);

        cubes.movement(width);

        for(int i=0;i<3;i++){
            player.boxX[i]=cubes.cubes[i].getPosition().x;
            player.boxY[i]=cubes.cubes[i].getPosition().y;
        }

        player.checkCollision(window);

        window.clear();
        window.draw(player);
        window.draw(cubes);
        window.display();
    }
}

int main(){Window();}