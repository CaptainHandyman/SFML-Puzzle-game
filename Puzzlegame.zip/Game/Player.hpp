#ifndef PLAYER_HPP
#define PLAYER_HPP

#include <SFML/Graphics.hpp>

class Player : public sf::Drawable{
public:
    Player(int width);

    void actions(int window_width,
                 int window_height);

    void checkCollision(int windowWidth);

    float boxX[3];

    float boxY[3];

    int dies=0;

private:
    void moveRight(int window_width);

    void moveLeft(int window_width);

    void moveUp(int window_height);

    void moveDown(int window_height);

    void keyboard(int window_width,
                  int window_height);

    void draw(sf::RenderTarget &target, sf::RenderStates states) const{
        target.draw(player, states);
    }

    int window_width=0;

    bool sides[4];

    sf::Vector2f point;

    const int width=100;
    const int height=100;

    sf::RectangleShape player;
};

#endif // PLAYTER_HPP