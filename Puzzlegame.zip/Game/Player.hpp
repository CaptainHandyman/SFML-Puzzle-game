#ifndef PLAYER_HPP
#define PLAYER_HPP

#include <SFML/Graphics.hpp>

class Player : public sf::Drawable{
public:
    Player();

    void actions(int window_width,
                 int window_height,
                 sf::RenderWindow &window);

    void moveRight(int window_width);

    void moveLeft(int window_width);

    void moveUp(int window_height);

    void moveDown(int window_height);

    void keyboard(int window_width,
                  int window_height,
                  sf::RenderWindow &window);

    void checkCollision(sf::RenderWindow &window);

    float boxX[3];

    float boxY[3];

private:
    void draw(sf::RenderTarget &target, sf::RenderStates states) const{
        target.draw(player, states);
    }

    bool sides[4];

    sf::Vector2f point;

    const int width=100;
    const int height=100;

    sf::RectangleShape player;
};

#endif // PLAYTER_HPP