#ifndef SCARRY_HPP
#define SCARRY_HPP

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

class Scarry : public sf::Drawable{
public:
    Scarry();

    void soundPlay();

    bool playSound;

    bool drawImage;

private:
    void draw(sf::RenderTarget &target, sf::RenderStates states) const{
        target.draw(sprite, states);
    }

    sf::SoundBuffer buffer;
    sf::Sound sound;

    sf::Texture texture;
    sf::Sprite sprite;
};

#endif // SCARRY_HPP
